from maix import app, camera, display, image, nn, uart, network, err, webrtc
import platform

# ============================================================
# 1. WiFi 热点
# ============================================================
_SSID     = platform.node()
_PASSWORD = "88888888"
_DEV_IP   = ''

def start_ap(ssid, password):
    w = network.wifi.Wifi()
    if not w.is_ap_mode():
        e = w.start_ap(ssid, password)
        err.check_raise(e, "start wifi ap failed")
    global _DEV_IP
    _DEV_IP = w.get_ip()
    print("Start AP success, ip:", _DEV_IP)
    return _DEV_IP

# ============================================================
# 2. 串口初始化
# ============================================================
serial = uart.UART("/dev/ttyS0", 115200)

# ============================================================
# 3. 模型与摄像头
# ============================================================
detector = nn.YOLO26(model="/root/my_models/yolo26_ball_2.mud", dual_buff=True)
# 主摄像头：采用检测器需要的格式（如 RGB888）
cam = camera.Camera(detector.input_width(), detector.input_height(), detector.input_format())
# 添加一个推流专用通道，格式固定为 YVU420SP，分辨率可自定义（此处设为 480×360）
cam_stream = cam.add_channel(480, 360, image.Format.FMT_YVU420SP)

disp = display.Display()
print(f"YOLO26n 已加载, 分辨率: {detector.input_width()}x{detector.input_height()}")

# ============================================================
# 4. 辅助：绘制白色十字
# ============================================================
def draw_white_cross(img, cx, cy, length=12, color=image.COLOR_WHITE):
    img.draw_line(cx - length, cy, cx + length, cy, color=color, thickness=1)
    img.draw_line(cx, cy - length, cx, cy + length, color=color, thickness=1)

# ============================================================
# 5. 主函数
# ============================================================
def main():
    ip = start_ap(_SSID, _PASSWORD)
    print("WiFi AP IP:", ip)

    # 启动 WebRTC 推流（使用专门添加的通道）
    server = webrtc.WebRTC()
    server.bind_camera(cam_stream)   
    server.start()
    print("WebRTC server started, connect via browser to", ip)

    # 主循环：检测 + 本地显示 + 串口发送
    while not app.need_exit():
        img = cam.read()               # 读取主摄像头帧（用于检测）
        objs = detector.detect(img, conf_th=0.5, iou_th=0.45)

        for obj in objs:
            cx = obj.x + obj.w // 2
            cy = obj.y + obj.h // 2

            # 本地绘制
            img.draw_rect(obj.x, obj.y, obj.w, obj.h, color=image.COLOR_RED)
            msg = f"{detector.labels[obj.class_id]}: {obj.score:.2f}"
            img.draw_string(obj.x, obj.y, msg, color=image.COLOR_RED)
            draw_white_cross(img, cx, cy)

            # 控制台打印
            print(f"中心: ({cx}, {cy}) | 置信度: {obj.score:.2f}")

            # 串口发送坐标
            coord_str = f"{cx},{cy}\n"
            serial.write(coord_str.encode())

        # 显示处理后的画面
        disp.show(img)

if __name__ == "__main__":
    main()