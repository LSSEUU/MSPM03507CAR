import gc
import os
import platform
import time
import traceback

from maix import app, camera, err, image, nn, uart, webrtc


APP_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(APP_DIR, "models", "yolo26_ball_2.mud")

UART_PORT = "/dev/ttyS0"
UART_BAUD = 115200
CONF_THRESHOLD = 0.5
IOU_THRESHOLD = 0.45
WEBRTC_HTTP_PORT = 8000
WEBRTC_SIGNALING_PORT = 8001
RETRY_MAX_SECONDS = 10


def _sleep_until_retry(seconds):
    """分段等待，以便 USER 键或 MaixVision 停止请求能尽快生效。"""
    deadline = time.time() + seconds
    while not app.need_exit() and time.time() < deadline:
        time.sleep(min(0.2, max(0, deadline - time.time())))


def _safe_close(name, resource, method="close"):
    if resource is None:
        return
    close_fn = getattr(resource, method, None)
    if close_fn is None:
        return
    try:
        close_fn()
    except Exception as exc:
        print("[cleanup] {} failed: {}".format(name, exc))


def _check_model_files():
    if not os.path.isfile(MODEL_PATH):
        raise RuntimeError("model descriptor not found: {}".format(MODEL_PATH))

    model_dir = os.path.dirname(MODEL_PATH)
    cvimodel_path = os.path.join(model_dir, "yolo26_ball_2.cvimodel")
    if not os.path.isfile(cvimodel_path):
        raise RuntimeError("model data not found: {}".format(cvimodel_path))


def run_once():
    """初始化并运行一次；异常交给外层清理后重试。"""
    serial = None
    detector = None
    cam_stream = None
    cam_detect = None
    server = None
    server_started = False

    try:
        _check_model_files()
        detector = nn.YOLO26(model=MODEL_PATH, dual_buff=True)
        width = detector.input_width()
        height = detector.input_height()
        detect_format = detector.input_format()
        if width <= 0 or height <= 0:
            raise RuntimeError(
                "invalid detector input size: {}x{}".format(width, height)
            )
        print("[model] YOLO26 ready: {}x{}, {}".format(width, height, MODEL_PATH))

        serial = uart.UART(UART_PORT, UART_BAUD)
        if serial is None:
            raise RuntimeError("UART initialization returned None")
        print("[uart] ready: {} @ {}".format(UART_PORT, UART_BAUD))

        # WebRTC 主通道必须为 NV21；副通道转换为模型要求的 RGB 格式。
        cam_stream = camera.Camera(width, height, image.Format.FMT_YVU420SP)
        if cam_stream is None:
            raise RuntimeError("camera initialization returned None")
        cam_detect = cam_stream.add_channel(width, height, detect_format)
        if cam_detect is None:
            raise RuntimeError("camera detection channel initialization returned None")
        print("[camera] stream NV21; detection channel {}x{}".format(width, height))

        # 默认端口为 HTTP 8000、信令 8001；不指定网卡即监听所有接口。
        server = webrtc.WebRTC()
        err.check_raise(server.bind_camera(cam_stream), "bind WebRTC camera failed")
        err.check_raise(server.start(), "start WebRTC server failed")
        server_started = True

        hostname = platform.node() or "maixcam-d410"
        print(
            "[webrtc] fixed URL: http://{}.local:{}".format(
                hostname, WEBRTC_HTTP_PORT
            )
        )
        for url in server.get_urls():
            print("[webrtc] URL:", url)
        print("[app] recognition and UART continue even when Wi-Fi is disconnected")

        while not app.need_exit():
            frame = cam_detect.read()
            if frame is None:
                raise RuntimeError("camera returned an empty frame")

            objects = detector.detect(
                frame,
                conf_th=CONF_THRESHOLD,
                iou_th=IOU_THRESHOLD,
            )
            if not objects:
                continue

            for obj in objects:
                center_x = obj.x + obj.w // 2
                center_y = obj.y + obj.h // 2
                written = serial.write_str("{},{}\n".format(center_x, center_y))
                if written is None or written < 0:
                    print(
                        "[uart] write failed for center ({}, {}): {}".format(
                            center_x, center_y, written
                        )
                    )

        print("[app] stop requested")
    finally:
        # 先停推流，再释放其依赖的摄像头通道，最后释放串口和模型。
        if server_started:
            _safe_close("WebRTC server", server, "stop")
        _safe_close("detection camera", cam_detect)
        _safe_close("stream camera", cam_stream)
        _safe_close("UART", serial)
        server = None
        cam_detect = None
        cam_stream = None
        serial = None
        detector = None
        gc.collect()


def main():
    retry_seconds = 2
    while not app.need_exit():
        try:
            run_once()
            break
        except Exception as exc:
            print("[app] runtime failure: {}".format(exc))
            traceback.print_exc()
            if app.need_exit():
                break
            print("[app] retrying in {} seconds".format(retry_seconds))
            _sleep_until_retry(retry_seconds)
            retry_seconds = min(retry_seconds * 2, RETRY_MAX_SECONDS)

    print("[app] exited cleanly")


if __name__ == "__main__":
    main()
